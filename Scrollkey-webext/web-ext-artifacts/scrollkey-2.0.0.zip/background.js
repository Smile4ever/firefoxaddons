// Prefs to migrate from Scrollkey 1.1.0
const PREFS = {
	"scrollkey_scrollvalue": {
		"type": "value",
		"default": 400
	},
	"scrollkey_scrollvalue_shift": {
		"type": "value",
		"default": 400
	},
	"scrollkey_scrollvalue_alt": {
		"type": "value",
		"default": 400
	},
	"scrollkey_horizontal_scroll": {
		"type": "checked",
		"default": false
	},
	"scrollkey_horizontal_scroll_shift": {
		"type": "checked",
		"default": false
	},
	"scrollkey_horizontal_scroll_alt": {
		"type": "checked",
		"default": false
	},
	"scrollkey_scroll_pagedown_pageup": {
		"type": "checked",
		"default": false
	}
};

///Messages
// listen for messages from the content or options script
browser.runtime.onMessage.addListener(function(message) {
	switch (message.action) {
		case "notify":
			notify(message.data);
			break;
		default:
			break;
	}
});

// See also https://developer.mozilla.org/en-US/Add-ons/WebExtensions/API/Tabs/sendMessage
function sendMessage(action, data){
	function logTabs(tabs) {
		for (tab of tabs) {
			browser.tabs.sendMessage(tab.id, {"action": action, "data": data});
		}
	}

	browser.tabs.query({currentWindow: true, active: true}).then(logTabs, onError);
}

/// Migrate preferences from Scrollkey 1.1.0 to 2.0
function migrateOptions() {
	browser.storage.sync.get(Object.keys(PREFS)).then((result) => {
		// result
		// { scrollkey_scrollvalue: "400", scrollkey_scrollvalue_shift: "400", scrollkey_scrollvalue_alt: "400", scrollkey_horizontal_scroll: false, scrollkey_horizontal_scroll_shift: false, scrollkey_horizontal_scroll_alt: false, scrollkey_scroll_pagedown_pageup: false }
		
		//console.log("migrateOptions from sync storage:");
		//console.log(result);
		
		let hasSyncData = false;
		for(let p in PREFS) {
			if(p in result) {
				// Set sync value from local value.
				hasSyncData = true;
			}
		}
		
		//console.log("migrateOptions hasSyncData " + hasSyncData);
		
		if(hasSyncData){
			return;
		}
		
		browser.storage.local.get(Object.keys(PREFS)).then((localResult) => {
			browser.storage.sync.set(localResult).then(() => {
				//console.log("migrateOptions from local storage:");
				//console.log(localResult);
				//console.log("Migrated options from local to sync!");
			});
		}).catch(console.error);
		
	}).catch(console.error);
}
migrateOptions();

/// Helper functions
function onError(error) {
	//console.log(`Error: ${error}`);
}

function notify(message){
	browser.notifications.create(message.substring(0, 20).replace(" ", ""),
	{
		type: "basic",
		iconUrl: browser.extension.getURL("icons/scrollkey.svg"),
		title: "Scrollkey",
		message: message
	});
}
