Translate Now
=============

Right click a selection to translate words in Firefox.

![Translate Now 1.0 without submenu](images/translate-now-contextmenuitem.png)

![Translate Now 1.0 - Preferences](images/translate-now-preferences.png)

If you enable Speak with Google Translate Voice, the context menu item changes into a submenu:
![Translate Now 1.0 with submenu](images/translate-now-submenu.png)
