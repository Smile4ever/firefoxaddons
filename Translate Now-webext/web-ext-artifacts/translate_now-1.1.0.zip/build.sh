#!/bin/bash
web-ext build --ignore-files webext-build.sh images README.md