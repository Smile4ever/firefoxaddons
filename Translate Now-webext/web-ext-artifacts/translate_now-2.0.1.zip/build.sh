#!/bin/bash
web-ext build --ignore-files build.sh images *.md